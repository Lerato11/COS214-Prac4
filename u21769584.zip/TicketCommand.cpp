#include "TicketCommand.h"

TicketCommand::TicketCommand(){

}

TicketCommand::~TicketCommand(){

}


// void TicketCommand::execute(std::string id, std::string info){
    
// }


// std::string TicketCommand::getType(){
    
// }