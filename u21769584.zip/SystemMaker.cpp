#include "SystemMaker.h"

// void SystemMaker::reset(){

// }

SystemMaker::~SystemMaker(){

}

// void SystemMaker::addCategory(std::string name){
    
// }

// void SystemMaker::addFinanceTicket(std::string id, std::string info){
    
// }

// void SystemMaker::addTechTicket(std::string id, std::string info){
    
// }

// void SystemMaker::addGeneralTicket(std::string id, std::string info){
    
// }

