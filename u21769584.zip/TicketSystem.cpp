#include "TicketSystem.h"

TicketSystem::TicketSystem(){

}


TicketSystem::~TicketSystem(){

}


// void TicketSystem::print(){
    
// }


// void TicketSystem::add(TicketSystem* item){
    
// }